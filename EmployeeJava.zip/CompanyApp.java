package Project;

public class CompanyApp {
	public static void main(String[] args)
	{
		System.out.println("My Company by W. Tu");
		System.out.println();
		try
		{
			EmployeeID newEmployeeID = new EmployeeID("William");
			newEmployeeID.setEmployeeNumber();
			newEmployeeID.setHireDate(10, 12, 2024);
			System.out.println(newEmployeeID);

			ProductionWorker newProductionWorker = new ProductionWorker("John");
			newProductionWorker.setPayRate(19.50);
			newProductionWorker.setHireDate(12, 4, 2024);
			System.out.println(newProductionWorker);

			ShiftSupervisor newShiftSupervisor = new ShiftSupervisor("Axel");
			newShiftSupervisor.setAnnualSalary(80000);
			newShiftSupervisor.setYearlyBonus(1000);
			newShiftSupervisor.setHireDate(8, 12, 2024);
			System.out.println(newShiftSupervisor);

			TeamLeader newTeamLeader = new TeamLeader("Henry", 200);
			newTeamLeader.setShift(2);
			newTeamLeader.setHireDate(9, 23, 2024);
			newTeamLeader.setRequiredTrainingHours(8);
			newTeamLeader.setTrainingHoursAttended(4);
			System.out.println(newTeamLeader);

		} catch (IllegalArgumentException e)
		{
			System.out.println(e.getMessage());
		}
	}
}
