package Project;

class ShiftSupervisor extends Employee
{
	private int yearlyBonus;
	private int annualSalary;
	private EmployeeID employeeID;
	public ShiftSupervisor(String name)
	{
		super(name);
		employeeID = new EmployeeID(this);
		setAnnualSalary(this.annualSalary);
		setYearlyBonus(this.yearlyBonus);
	}

	public void setAnnualSalary(int annualSalary)
	{
		this.annualSalary = annualSalary;
	}

	public void setYearlyBonus(int yearlyBonus)
	{
		this.yearlyBonus = yearlyBonus;
	}

	public int getAnnualSalary() { return annualSalary; }

	public int getYearlyBonus() { return yearlyBonus; }

	public String getEmployeeNumber() { return employeeID.getEmployeeNumber(); }

	@Override
	public String toString()
	{
		return "Name: " + getName() + " || ID: " + getEmployeeNumber() + " || Hire Date: " + getHireDate() + " || Annual Salary: " + getAnnualSalary() + " || Annual Bonus: " + getYearlyBonus();
	}
}