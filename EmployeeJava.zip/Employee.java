package Project;
import java.util.Random;

class Employee 
{
	protected Random rand = new Random();
	protected String name, employeeNumber, hireDate;
	protected int firstNum, secondNum, thirdNum, month, day, year;

	public Employee(String name)
	{
		setName(name);
	}

	public Employee(Employee employee)
	{
		setName(employee.getName());
	}

	public void setName(String name) { this.name = name; }

	public void setHireDate(int month, int day, int year) 
	{ 
		String formattedMonth = String.format("%02d", month);
		String formattedDay = String.format("%02d", day);
		String date = "" + formattedMonth + "/" + formattedDay + "/" + year;
		Date.validateDate(date);
		this.hireDate = date;
	}

	public String getName() { return name; }

	public String getHireDate() { return hireDate; }

	@Override
	public String toString()
	{
		return "Name: " + getName() + " || ID: " + this.employeeNumber + " || Hire Date: " + getHireDate();
	}


}