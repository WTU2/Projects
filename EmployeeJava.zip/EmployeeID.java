package Project;

class EmployeeID extends Employee
{
	public EmployeeID(String name)
	{
		super(name);	
		setEmployeeNumber();
	}

	public EmployeeID(Employee employee)
	{
		super(employee);
		setEmployeeNumber();
	}

	public void setEmployeeNumber()
	{
		firstNum = rand.nextInt(10);
		secondNum = rand.nextInt(10);
		thirdNum = rand.nextInt(10);
		char letter = (char)(rand.nextInt(13) + 'A');

		this.employeeNumber = "" + firstNum + secondNum + thirdNum + "-" + letter;

		if (!employeeNumber.matches("\\d{3}-[A-M]"))
		{
			throw new IllegalArgumentException("Employee ID: " + employeeNumber + "Name: " + getName() + " is not in the correct format.");
		}
	}

	public String getEmployeeNumber() { return employeeNumber; }
	
}
