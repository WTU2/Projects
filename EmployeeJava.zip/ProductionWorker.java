package Project;

class ProductionWorker extends Employee
{
	private int shift = 1; // automatically day shift
	private double payRate = 17.50;
	private EmployeeID employeeID;
	public ProductionWorker(String name)
	{
		super(name);
		employeeID = new EmployeeID(this);
		setShift(this.shift);
		setPayRate(this.payRate);
	}

	public void setPayRate(double payRate) { this.payRate = payRate; }

	public void setShift(int shift) { this.shift = shift; }

	public String getShift()
	{
		if (shift == 1)
		{
			return "Day Shift";
		}
		else
		{
			return "Night Shift";
		}
	}

	public double getPayRate() { return payRate; }

	public String getEmployeeNumber()
	{
		return employeeID.getEmployeeNumber();
	}

	@Override
	public String toString()
	{
		return "Name: " + getName() + " || ID: " + getEmployeeNumber() + " || Hire Date: " + getHireDate() + " || Shift: " + getShift() + " || Pay Rate: " + getPayRate();
	}
}
