package Project;

public class Date{
	private static final String datePattern = "^(0[1-9]|1[0-2])/([0-2][0-9]|3[0-1])/\\d{4}$";

	public static void validateDate(String date)
	{
		if (!date.matches(datePattern))
		{
			throw new IllegalArgumentException("Invalid date format: " + date);
		}
	}

}