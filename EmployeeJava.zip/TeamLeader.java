package Project;

class TeamLeader extends ProductionWorker
{
	private int monthlyBonus, requiredTrainingHours, trainingHoursAttended;

	public TeamLeader(String name, int monthlyBonus)
	{
		super(name);
		setMonthlyBonus(monthlyBonus);
	}

	public void setMonthlyBonus(int monthlyBonus) { this.monthlyBonus = monthlyBonus; }

	public void setRequiredTrainingHours(int requiredTrainingHours) { this.requiredTrainingHours = requiredTrainingHours; }

	public void setTrainingHoursAttended(int trainingHoursAttended) {this.trainingHoursAttended = trainingHoursAttended; }

	public int getMonthlyBonus() { return monthlyBonus; }

	public int getRequiredTrainingHours() { return requiredTrainingHours; }

	public int getTrainingHoursAttended() { return trainingHoursAttended; }

	@Override
	public String toString()
	{
		return "Name: " + getName() + " || ID: " + getEmployeeNumber() + " || Hire Date: " + getHireDate() + " || Shift: " + getShift() + " || Pay Rate: " + getPayRate() + " || Monthly Bonus: " + getMonthlyBonus() + " || Required Training Hours: " + getRequiredTrainingHours() + " || Training Hours Completed: " + getTrainingHoursAttended();
	}
}